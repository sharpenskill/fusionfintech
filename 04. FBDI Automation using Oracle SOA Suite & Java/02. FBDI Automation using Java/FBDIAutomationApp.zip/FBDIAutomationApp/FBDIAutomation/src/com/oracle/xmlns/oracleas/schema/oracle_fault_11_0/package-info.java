@javax.xml.bind.annotation.XmlSchema(namespace = "http://xmlns.oracle.com/oracleas/schema/oracle-fault-11_0")
package com.oracle.xmlns.oracleas.schema.oracle_fault_11_0;

