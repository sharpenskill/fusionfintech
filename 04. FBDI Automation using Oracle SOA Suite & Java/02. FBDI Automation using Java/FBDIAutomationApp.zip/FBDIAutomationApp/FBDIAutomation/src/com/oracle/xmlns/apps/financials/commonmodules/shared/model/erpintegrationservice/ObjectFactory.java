
package com.oracle.xmlns.apps.financials.commonmodules.shared.model.erpintegrationservice;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each
 * Java content interface and Java element interface
 * generated in the com.oracle.xmlns.apps.financials.commonmodules.shared.model.erpintegrationservice package.
 * <p>An ObjectFactory allows you to programatically
 * construct new instances of the Java representation
 * for XML content. The Java representation of XML
 * content can consist of schema derived interfaces
 * and classes representing the binding of schema
 * type definitions, element declarations and model
 * groups.  Factory methods for each of these are
 * provided in this class.
 *
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _EssJob_QNAME =
        new QName("http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/",
                  "essJob");
    private final static QName _DocumentDetails_QNAME =
        new QName("http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/",
                  "documentDetails");
    private final static QName _DocumentDetail_QNAME =
        new QName("http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/",
                  "documentDetail");
    private final static QName _DocumentDetailContent_QNAME =
        new QName("http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/",
                  "Content");
    private final static QName _DocumentDetailFileName_QNAME =
        new QName("http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/",
                  "FileName");
    private final static QName _DocumentDetailContentType_QNAME =
        new QName("http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/",
                  "ContentType");
    private final static QName _DocumentDetailDocumentTitle_QNAME =
        new QName("http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/",
                  "DocumentTitle");
    private final static QName _DocumentDetailDocumentAuthor_QNAME =
        new QName("http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/",
                  "DocumentAuthor");
    private final static QName _DocumentDetailDocumentSecurityGroup_QNAME =
        new QName("http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/",
                  "DocumentSecurityGroup");
    private final static QName _DocumentDetailDocumentAccount_QNAME =
        new QName("http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/",
                  "DocumentAccount");
    private final static QName _DocumentDetailDocumentName_QNAME =
        new QName("http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/",
                  "DocumentName");
    private final static QName _DocumentDetailDocumentId_QNAME =
        new QName("http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/",
                  "DocumentId");
    private final static QName _EssJobJobName_QNAME =
        new QName("http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/",
                  "JobName");
    private final static QName _EssJobParameterList_QNAME =
        new QName("http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/",
                  "ParameterList");
    private final static QName _EssJobJobRequestId_QNAME =
        new QName("http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/",
                  "JobRequestId");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.oracle.xmlns.apps.financials.commonmodules.shared.model.erpintegrationservice
     *
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link DocumentDetails }
     *
     */
    public DocumentDetails createDocumentDetails() {
        return new DocumentDetails();
    }

    /**
     * Create an instance of {@link EssJob }
     *
     */
    public EssJob createEssJob() {
        return new EssJob();
    }

    /**
     * Create an instance of {@link DocumentDetail }
     *
     */
    public DocumentDetail createDocumentDetail() {
        return new DocumentDetail();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EssJob }{@code >}
     *
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link EssJob }{@code >}
     */
    @XmlElementDecl(namespace =
                    "http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/",
                    name = "essJob")
    public JAXBElement<EssJob> createEssJob(EssJob value) {
        return new JAXBElement<EssJob>(_EssJob_QNAME, EssJob.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DocumentDetails }{@code >}
     *
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link DocumentDetails }{@code >}
     */
    @XmlElementDecl(namespace =
                    "http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/",
                    name = "documentDetails")
    public JAXBElement<DocumentDetails> createDocumentDetails(DocumentDetails value) {
        return new JAXBElement<DocumentDetails>(_DocumentDetails_QNAME, DocumentDetails.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DocumentDetail }{@code >}
     *
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link DocumentDetail }{@code >}
     */
    @XmlElementDecl(namespace =
                    "http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/",
                    name = "documentDetail")
    public JAXBElement<DocumentDetail> createDocumentDetail(DocumentDetail value) {
        return new JAXBElement<DocumentDetail>(_DocumentDetail_QNAME, DocumentDetail.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link byte[]}{@code >}
     *
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link byte[]}{@code >}
     */
    @XmlElementDecl(namespace =
                    "http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/",
                    name = "Content", scope = DocumentDetail.class)
    public JAXBElement<byte[]> createDocumentDetailContent(byte[] value) {
        return new JAXBElement<byte[]>(_DocumentDetailContent_QNAME, byte[].class, DocumentDetail.class,
                                       ((byte[]) value));
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     *
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace =
                    "http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/",
                    name = "FileName", scope = DocumentDetail.class)
    public JAXBElement<String> createDocumentDetailFileName(String value) {
        return new JAXBElement<String>(_DocumentDetailFileName_QNAME, String.class, DocumentDetail.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     *
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace =
                    "http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/",
                    name = "ContentType", scope = DocumentDetail.class)
    public JAXBElement<String> createDocumentDetailContentType(String value) {
        return new JAXBElement<String>(_DocumentDetailContentType_QNAME, String.class, DocumentDetail.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     *
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace =
                    "http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/",
                    name = "DocumentTitle", scope = DocumentDetail.class)
    public JAXBElement<String> createDocumentDetailDocumentTitle(String value) {
        return new JAXBElement<String>(_DocumentDetailDocumentTitle_QNAME, String.class, DocumentDetail.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     *
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace =
                    "http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/",
                    name = "DocumentAuthor", scope = DocumentDetail.class)
    public JAXBElement<String> createDocumentDetailDocumentAuthor(String value) {
        return new JAXBElement<String>(_DocumentDetailDocumentAuthor_QNAME, String.class, DocumentDetail.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     *
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace =
                    "http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/",
                    name = "DocumentSecurityGroup", scope = DocumentDetail.class)
    public JAXBElement<String> createDocumentDetailDocumentSecurityGroup(String value) {
        return new JAXBElement<String>(_DocumentDetailDocumentSecurityGroup_QNAME, String.class, DocumentDetail.class,
                                       value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     *
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace =
                    "http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/",
                    name = "DocumentAccount", scope = DocumentDetail.class)
    public JAXBElement<String> createDocumentDetailDocumentAccount(String value) {
        return new JAXBElement<String>(_DocumentDetailDocumentAccount_QNAME, String.class, DocumentDetail.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     *
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace =
                    "http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/",
                    name = "DocumentName", scope = DocumentDetail.class)
    public JAXBElement<String> createDocumentDetailDocumentName(String value) {
        return new JAXBElement<String>(_DocumentDetailDocumentName_QNAME, String.class, DocumentDetail.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     *
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace =
                    "http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/",
                    name = "DocumentId", scope = DocumentDetail.class)
    public JAXBElement<String> createDocumentDetailDocumentId(String value) {
        return new JAXBElement<String>(_DocumentDetailDocumentId_QNAME, String.class, DocumentDetail.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     *
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace =
                    "http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/",
                    name = "JobName", scope = EssJob.class)
    public JAXBElement<String> createEssJobJobName(String value) {
        return new JAXBElement<String>(_EssJobJobName_QNAME, String.class, EssJob.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     *
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace =
                    "http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/",
                    name = "ParameterList", scope = EssJob.class)
    public JAXBElement<String> createEssJobParameterList(String value) {
        return new JAXBElement<String>(_EssJobParameterList_QNAME, String.class, EssJob.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     *
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace =
                    "http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/",
                    name = "JobRequestId", scope = EssJob.class)
    public JAXBElement<String> createEssJobJobRequestId(String value) {
        return new JAXBElement<String>(_EssJobJobRequestId_QNAME, String.class, EssJob.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     *
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace =
                    "http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/",
                    name = "ContentType", scope = DocumentDetails.class)
    public JAXBElement<String> createDocumentDetailsContentType(String value) {
        return new JAXBElement<String>(_DocumentDetailContentType_QNAME, String.class, DocumentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     *
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace =
                    "http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/",
                    name = "DocumentTitle", scope = DocumentDetails.class)
    public JAXBElement<String> createDocumentDetailsDocumentTitle(String value) {
        return new JAXBElement<String>(_DocumentDetailDocumentTitle_QNAME, String.class, DocumentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     *
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace =
                    "http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/",
                    name = "DocumentAuthor", scope = DocumentDetails.class)
    public JAXBElement<String> createDocumentDetailsDocumentAuthor(String value) {
        return new JAXBElement<String>(_DocumentDetailDocumentAuthor_QNAME, String.class, DocumentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     *
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace =
                    "http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/",
                    name = "DocumentSecurityGroup", scope = DocumentDetails.class)
    public JAXBElement<String> createDocumentDetailsDocumentSecurityGroup(String value) {
        return new JAXBElement<String>(_DocumentDetailDocumentSecurityGroup_QNAME, String.class, DocumentDetails.class,
                                       value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     *
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace =
                    "http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/",
                    name = "DocumentAccount", scope = DocumentDetails.class)
    public JAXBElement<String> createDocumentDetailsDocumentAccount(String value) {
        return new JAXBElement<String>(_DocumentDetailDocumentAccount_QNAME, String.class, DocumentDetails.class,
                                       value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     *
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace =
                    "http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/",
                    name = "DocumentName", scope = DocumentDetails.class)
    public JAXBElement<String> createDocumentDetailsDocumentName(String value) {
        return new JAXBElement<String>(_DocumentDetailDocumentName_QNAME, String.class, DocumentDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     *
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace =
                    "http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/",
                    name = "DocumentId", scope = DocumentDetails.class)
    public JAXBElement<String> createDocumentDetailsDocumentId(String value) {
        return new JAXBElement<String>(_DocumentDetailDocumentId_QNAME, String.class, DocumentDetails.class, value);
    }

}
