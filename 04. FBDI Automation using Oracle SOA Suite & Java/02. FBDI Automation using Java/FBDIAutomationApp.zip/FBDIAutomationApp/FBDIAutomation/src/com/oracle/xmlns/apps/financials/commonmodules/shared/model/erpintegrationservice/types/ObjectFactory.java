
package com.oracle.xmlns.apps.financials.commonmodules.shared.model.erpintegrationservice.types;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;

import com.oracle.xmlns.apps.financials.commonmodules.shared.model.erpintegrationservice.DocumentDetail;


/**
 * This object contains factory methods for each
 * Java content interface and Java element interface
 * generated in the com.oracle.xmlns.apps.financials.commonmodules.shared.model.erpintegrationservice.types package.
 * <p>An ObjectFactory allows you to programatically
 * construct new instances of the Java representation
 * for XML content. The Java representation of XML
 * content can consist of schema derived interfaces
 * and classes representing the binding of schema
 * type definitions, element declarations and model
 * groups.  Factory methods for each of these are
 * provided in this class.
 *
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _LoadAndImportDataInterfaceDetails_QNAME =
        new QName("http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/types/",
                  "interfaceDetails");
    private final static QName _LoadAndImportDataNotificationCode_QNAME =
        new QName("http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/types/",
                  "notificationCode");
    private final static QName _LoadAndImportDataCallbackURL_QNAME =
        new QName("http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/types/",
                  "callbackURL");
    private final static QName _ImportBulkDataDocument_QNAME =
        new QName("http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/types/",
                  "document");
    private final static QName _ImportBulkDataJobOptions_QNAME =
        new QName("http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/types/",
                  "jobOptions");
    private final static QName _ExportBulkDataParameterList_QNAME =
        new QName("http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/types/",
                  "parameterList");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.oracle.xmlns.apps.financials.commonmodules.shared.model.erpintegrationservice.types
     *
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link GetESSJobStatus }
     *
     */
    public GetESSJobStatus createGetESSJobStatus() {
        return new GetESSJobStatus();
    }

    /**
     * Create an instance of {@link GetESSJobStatusResponse }
     *
     */
    public GetESSJobStatusResponse createGetESSJobStatusResponse() {
        return new GetESSJobStatusResponse();
    }

    /**
     * Create an instance of {@link GetDfltObjAttrHints }
     *
     */
    public GetDfltObjAttrHints createGetDfltObjAttrHints() {
        return new GetDfltObjAttrHints();
    }

    /**
     * Create an instance of {@link GetDfltObjAttrHintsResponse }
     *
     */
    public GetDfltObjAttrHintsResponse createGetDfltObjAttrHintsResponse() {
        return new GetDfltObjAttrHintsResponse();
    }

    /**
     * Create an instance of {@link GetServiceLastUpdateTime }
     *
     */
    public GetServiceLastUpdateTime createGetServiceLastUpdateTime() {
        return new GetServiceLastUpdateTime();
    }

    /**
     * Create an instance of {@link GetServiceLastUpdateTimeResponse }
     *
     */
    public GetServiceLastUpdateTimeResponse createGetServiceLastUpdateTimeResponse() {
        return new GetServiceLastUpdateTimeResponse();
    }

    /**
     * Create an instance of {@link GetEntityList }
     *
     */
    public GetEntityList createGetEntityList() {
        return new GetEntityList();
    }

    /**
     * Create an instance of {@link GetEntityListResponse }
     *
     */
    public GetEntityListResponse createGetEntityListResponse() {
        return new GetEntityListResponse();
    }

    /**
     * Create an instance of {@link GetEntityListAsync }
     *
     */
    public GetEntityListAsync createGetEntityListAsync() {
        return new GetEntityListAsync();
    }

    /**
     * Create an instance of {@link GetEntityListAsyncResponse }
     *
     */
    public GetEntityListAsyncResponse createGetEntityListAsyncResponse() {
        return new GetEntityListAsyncResponse();
    }

    /**
     * Create an instance of {@link GetESSJobStatusAsync }
     *
     */
    public GetESSJobStatusAsync createGetESSJobStatusAsync() {
        return new GetESSJobStatusAsync();
    }

    /**
     * Create an instance of {@link GetESSJobStatusAsyncResponse }
     *
     */
    public GetESSJobStatusAsyncResponse createGetESSJobStatusAsyncResponse() {
        return new GetESSJobStatusAsyncResponse();
    }

    /**
     * Create an instance of {@link GetDfltObjAttrHintsAsync }
     *
     */
    public GetDfltObjAttrHintsAsync createGetDfltObjAttrHintsAsync() {
        return new GetDfltObjAttrHintsAsync();
    }

    /**
     * Create an instance of {@link GetDfltObjAttrHintsAsyncResponse }
     *
     */
    public GetDfltObjAttrHintsAsyncResponse createGetDfltObjAttrHintsAsyncResponse() {
        return new GetDfltObjAttrHintsAsyncResponse();
    }

    /**
     * Create an instance of {@link GetServiceLastUpdateTimeAsync }
     *
     */
    public GetServiceLastUpdateTimeAsync createGetServiceLastUpdateTimeAsync() {
        return new GetServiceLastUpdateTimeAsync();
    }

    /**
     * Create an instance of {@link GetServiceLastUpdateTimeAsyncResponse }
     *
     */
    public GetServiceLastUpdateTimeAsyncResponse createGetServiceLastUpdateTimeAsyncResponse() {
        return new GetServiceLastUpdateTimeAsyncResponse();
    }

    /**
     * Create an instance of {@link SubmitESSJobRequest }
     *
     */
    public SubmitESSJobRequest createSubmitESSJobRequest() {
        return new SubmitESSJobRequest();
    }

    /**
     * Create an instance of {@link SubmitESSJobRequestResponse }
     *
     */
    public SubmitESSJobRequestResponse createSubmitESSJobRequestResponse() {
        return new SubmitESSJobRequestResponse();
    }

    /**
     * Create an instance of {@link SubmitESSJobRequestAsync }
     *
     */
    public SubmitESSJobRequestAsync createSubmitESSJobRequestAsync() {
        return new SubmitESSJobRequestAsync();
    }

    /**
     * Create an instance of {@link SubmitESSJobRequestAsyncResponse }
     *
     */
    public SubmitESSJobRequestAsyncResponse createSubmitESSJobRequestAsyncResponse() {
        return new SubmitESSJobRequestAsyncResponse();
    }

    /**
     * Create an instance of {@link SubmitJobWithOutput }
     *
     */
    public SubmitJobWithOutput createSubmitJobWithOutput() {
        return new SubmitJobWithOutput();
    }

    /**
     * Create an instance of {@link SubmitJobWithOutputResponse }
     *
     */
    public SubmitJobWithOutputResponse createSubmitJobWithOutputResponse() {
        return new SubmitJobWithOutputResponse();
    }

    /**
     * Create an instance of {@link SubmitJobWithOutputAsync }
     *
     */
    public SubmitJobWithOutputAsync createSubmitJobWithOutputAsync() {
        return new SubmitJobWithOutputAsync();
    }

    /**
     * Create an instance of {@link SubmitJobWithOutputAsyncResponse }
     *
     */
    public SubmitJobWithOutputAsyncResponse createSubmitJobWithOutputAsyncResponse() {
        return new SubmitJobWithOutputAsyncResponse();
    }

    /**
     * Create an instance of {@link GetDocumentIdsForFilePrefix }
     *
     */
    public GetDocumentIdsForFilePrefix createGetDocumentIdsForFilePrefix() {
        return new GetDocumentIdsForFilePrefix();
    }

    /**
     * Create an instance of {@link GetDocumentIdsForFilePrefixResponse }
     *
     */
    public GetDocumentIdsForFilePrefixResponse createGetDocumentIdsForFilePrefixResponse() {
        return new GetDocumentIdsForFilePrefixResponse();
    }

    /**
     * Create an instance of {@link GetDocumentIdsForFilePrefixAsync }
     *
     */
    public GetDocumentIdsForFilePrefixAsync createGetDocumentIdsForFilePrefixAsync() {
        return new GetDocumentIdsForFilePrefixAsync();
    }

    /**
     * Create an instance of {@link GetDocumentIdsForFilePrefixAsyncResponse }
     *
     */
    public GetDocumentIdsForFilePrefixAsyncResponse createGetDocumentIdsForFilePrefixAsyncResponse() {
        return new GetDocumentIdsForFilePrefixAsyncResponse();
    }

    /**
     * Create an instance of {@link GetDocumentForDocumentId }
     *
     */
    public GetDocumentForDocumentId createGetDocumentForDocumentId() {
        return new GetDocumentForDocumentId();
    }

    /**
     * Create an instance of {@link GetDocumentForDocumentIdResponse }
     *
     */
    public GetDocumentForDocumentIdResponse createGetDocumentForDocumentIdResponse() {
        return new GetDocumentForDocumentIdResponse();
    }

    /**
     * Create an instance of {@link GetDocumentForDocumentIdAsync }
     *
     */
    public GetDocumentForDocumentIdAsync createGetDocumentForDocumentIdAsync() {
        return new GetDocumentForDocumentIdAsync();
    }

    /**
     * Create an instance of {@link GetDocumentForDocumentIdAsyncResponse }
     *
     */
    public GetDocumentForDocumentIdAsyncResponse createGetDocumentForDocumentIdAsyncResponse() {
        return new GetDocumentForDocumentIdAsyncResponse();
    }

    /**
     * Create an instance of {@link GetDocumentsForFilePrefix }
     *
     */
    public GetDocumentsForFilePrefix createGetDocumentsForFilePrefix() {
        return new GetDocumentsForFilePrefix();
    }

    /**
     * Create an instance of {@link GetDocumentsForFilePrefixResponse }
     *
     */
    public GetDocumentsForFilePrefixResponse createGetDocumentsForFilePrefixResponse() {
        return new GetDocumentsForFilePrefixResponse();
    }

    /**
     * Create an instance of {@link GetDocumentsForFilePrefixAsync }
     *
     */
    public GetDocumentsForFilePrefixAsync createGetDocumentsForFilePrefixAsync() {
        return new GetDocumentsForFilePrefixAsync();
    }

    /**
     * Create an instance of {@link GetDocumentsForFilePrefixAsyncResponse }
     *
     */
    public GetDocumentsForFilePrefixAsyncResponse createGetDocumentsForFilePrefixAsyncResponse() {
        return new GetDocumentsForFilePrefixAsyncResponse();
    }

    /**
     * Create an instance of {@link UploadFileToUcm }
     *
     */
    public UploadFileToUcm createUploadFileToUcm() {
        return new UploadFileToUcm();
    }

    /**
     * Create an instance of {@link UploadFileToUcmResponse }
     *
     */
    public UploadFileToUcmResponse createUploadFileToUcmResponse() {
        return new UploadFileToUcmResponse();
    }

    /**
     * Create an instance of {@link UploadFileToUcmAsync }
     *
     */
    public UploadFileToUcmAsync createUploadFileToUcmAsync() {
        return new UploadFileToUcmAsync();
    }

    /**
     * Create an instance of {@link UploadFileToUcmAsyncResponse }
     *
     */
    public UploadFileToUcmAsyncResponse createUploadFileToUcmAsyncResponse() {
        return new UploadFileToUcmAsyncResponse();
    }

    /**
     * Create an instance of {@link DownloadESSJobExecutionDetails }
     *
     */
    public DownloadESSJobExecutionDetails createDownloadESSJobExecutionDetails() {
        return new DownloadESSJobExecutionDetails();
    }

    /**
     * Create an instance of {@link DownloadESSJobExecutionDetailsResponse }
     *
     */
    public DownloadESSJobExecutionDetailsResponse createDownloadESSJobExecutionDetailsResponse() {
        return new DownloadESSJobExecutionDetailsResponse();
    }

    /**
     * Create an instance of {@link AppendFileComment }
     *
     */
    public AppendFileComment createAppendFileComment() {
        return new AppendFileComment();
    }

    /**
     * Create an instance of {@link AppendFileCommentResponse }
     *
     */
    public AppendFileCommentResponse createAppendFileCommentResponse() {
        return new AppendFileCommentResponse();
    }

    /**
     * Create an instance of {@link AppendFileCommentAsync }
     *
     */
    public AppendFileCommentAsync createAppendFileCommentAsync() {
        return new AppendFileCommentAsync();
    }

    /**
     * Create an instance of {@link AppendFileCommentAsyncResponse }
     *
     */
    public AppendFileCommentAsyncResponse createAppendFileCommentAsyncResponse() {
        return new AppendFileCommentAsyncResponse();
    }

    /**
     * Create an instance of {@link DownloadESSJobExecutionDetailsAsync }
     *
     */
    public DownloadESSJobExecutionDetailsAsync createDownloadESSJobExecutionDetailsAsync() {
        return new DownloadESSJobExecutionDetailsAsync();
    }

    /**
     * Create an instance of {@link DownloadESSJobExecutionDetailsAsyncResponse }
     *
     */
    public DownloadESSJobExecutionDetailsAsyncResponse createDownloadESSJobExecutionDetailsAsyncResponse() {
        return new DownloadESSJobExecutionDetailsAsyncResponse();
    }

    /**
     * Create an instance of {@link DownloadExportOutput }
     *
     */
    public DownloadExportOutput createDownloadExportOutput() {
        return new DownloadExportOutput();
    }

    /**
     * Create an instance of {@link DownloadExportOutputResponse }
     *
     */
    public DownloadExportOutputResponse createDownloadExportOutputResponse() {
        return new DownloadExportOutputResponse();
    }

    /**
     * Create an instance of {@link DownloadExportOutputAsync }
     *
     */
    public DownloadExportOutputAsync createDownloadExportOutputAsync() {
        return new DownloadExportOutputAsync();
    }

    /**
     * Create an instance of {@link DownloadExportOutputAsyncResponse }
     *
     */
    public DownloadExportOutputAsyncResponse createDownloadExportOutputAsyncResponse() {
        return new DownloadExportOutputAsyncResponse();
    }

    /**
     * Create an instance of {@link LoadAndImportData }
     *
     */
    public LoadAndImportData createLoadAndImportData() {
        return new LoadAndImportData();
    }

    /**
     * Create an instance of {@link LoadAndImportDataResponse }
     *
     */
    public LoadAndImportDataResponse createLoadAndImportDataResponse() {
        return new LoadAndImportDataResponse();
    }

    /**
     * Create an instance of {@link LoadAndImportDataAsync }
     *
     */
    public LoadAndImportDataAsync createLoadAndImportDataAsync() {
        return new LoadAndImportDataAsync();
    }

    /**
     * Create an instance of {@link LoadAndImportDataAsyncResponse }
     *
     */
    public LoadAndImportDataAsyncResponse createLoadAndImportDataAsyncResponse() {
        return new LoadAndImportDataAsyncResponse();
    }

    /**
     * Create an instance of {@link ConfirmExtractConsumption }
     *
     */
    public ConfirmExtractConsumption createConfirmExtractConsumption() {
        return new ConfirmExtractConsumption();
    }

    /**
     * Create an instance of {@link ConfirmExtractConsumptionResponse }
     *
     */
    public ConfirmExtractConsumptionResponse createConfirmExtractConsumptionResponse() {
        return new ConfirmExtractConsumptionResponse();
    }

    /**
     * Create an instance of {@link ConfirmExtractConsumptionAsync }
     *
     */
    public ConfirmExtractConsumptionAsync createConfirmExtractConsumptionAsync() {
        return new ConfirmExtractConsumptionAsync();
    }

    /**
     * Create an instance of {@link ConfirmExtractConsumptionAsyncResponse }
     *
     */
    public ConfirmExtractConsumptionAsyncResponse createConfirmExtractConsumptionAsyncResponse() {
        return new ConfirmExtractConsumptionAsyncResponse();
    }

    /**
     * Create an instance of {@link UpdateInterfaceData }
     *
     */
    public UpdateInterfaceData createUpdateInterfaceData() {
        return new UpdateInterfaceData();
    }

    /**
     * Create an instance of {@link UpdateInterfaceDataResponse }
     *
     */
    public UpdateInterfaceDataResponse createUpdateInterfaceDataResponse() {
        return new UpdateInterfaceDataResponse();
    }

    /**
     * Create an instance of {@link UpdateInterfaceDataAsync }
     *
     */
    public UpdateInterfaceDataAsync createUpdateInterfaceDataAsync() {
        return new UpdateInterfaceDataAsync();
    }

    /**
     * Create an instance of {@link UpdateInterfaceDataAsyncResponse }
     *
     */
    public UpdateInterfaceDataAsyncResponse createUpdateInterfaceDataAsyncResponse() {
        return new UpdateInterfaceDataAsyncResponse();
    }

    /**
     * Create an instance of {@link ImportBulkData }
     *
     */
    public ImportBulkData createImportBulkData() {
        return new ImportBulkData();
    }

    /**
     * Create an instance of {@link ImportBulkDataResponse }
     *
     */
    public ImportBulkDataResponse createImportBulkDataResponse() {
        return new ImportBulkDataResponse();
    }

    /**
     * Create an instance of {@link ImportBulkDataAsync }
     *
     */
    public ImportBulkDataAsync createImportBulkDataAsync() {
        return new ImportBulkDataAsync();
    }

    /**
     * Create an instance of {@link ImportBulkDataAsyncResponse }
     *
     */
    public ImportBulkDataAsyncResponse createImportBulkDataAsyncResponse() {
        return new ImportBulkDataAsyncResponse();
    }

    /**
     * Create an instance of {@link ExtractAndPurge }
     *
     */
    public ExtractAndPurge createExtractAndPurge() {
        return new ExtractAndPurge();
    }

    /**
     * Create an instance of {@link ExtractAndPurgeResponse }
     *
     */
    public ExtractAndPurgeResponse createExtractAndPurgeResponse() {
        return new ExtractAndPurgeResponse();
    }

    /**
     * Create an instance of {@link ExtractAndPurgeAsync }
     *
     */
    public ExtractAndPurgeAsync createExtractAndPurgeAsync() {
        return new ExtractAndPurgeAsync();
    }

    /**
     * Create an instance of {@link ExtractAndPurgeAsyncResponse }
     *
     */
    public ExtractAndPurgeAsyncResponse createExtractAndPurgeAsyncResponse() {
        return new ExtractAndPurgeAsyncResponse();
    }

    /**
     * Create an instance of {@link ExportBulkData }
     *
     */
    public ExportBulkData createExportBulkData() {
        return new ExportBulkData();
    }

    /**
     * Create an instance of {@link ExportBulkDataResponse }
     *
     */
    public ExportBulkDataResponse createExportBulkDataResponse() {
        return new ExportBulkDataResponse();
    }

    /**
     * Create an instance of {@link ExportBulkDataAsync }
     *
     */
    public ExportBulkDataAsync createExportBulkDataAsync() {
        return new ExportBulkDataAsync();
    }

    /**
     * Create an instance of {@link ExportBulkDataAsyncResponse }
     *
     */
    public ExportBulkDataAsyncResponse createExportBulkDataAsyncResponse() {
        return new ExportBulkDataAsyncResponse();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     *
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace =
                    "http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/types/",
                    name = "interfaceDetails", scope = LoadAndImportData.class)
    public JAXBElement<String> createLoadAndImportDataInterfaceDetails(String value) {
        return new JAXBElement<String>(_LoadAndImportDataInterfaceDetails_QNAME, String.class, LoadAndImportData.class,
                                       value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     *
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace =
                    "http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/types/",
                    name = "notificationCode", scope = LoadAndImportData.class)
    public JAXBElement<String> createLoadAndImportDataNotificationCode(String value) {
        return new JAXBElement<String>(_LoadAndImportDataNotificationCode_QNAME, String.class, LoadAndImportData.class,
                                       value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     *
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace =
                    "http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/types/",
                    name = "callbackURL", scope = LoadAndImportData.class)
    public JAXBElement<String> createLoadAndImportDataCallbackURL(String value) {
        return new JAXBElement<String>(_LoadAndImportDataCallbackURL_QNAME, String.class, LoadAndImportData.class,
                                       value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     *
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace =
                    "http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/types/",
                    name = "interfaceDetails", scope = LoadAndImportDataAsync.class)
    public JAXBElement<String> createLoadAndImportDataAsyncInterfaceDetails(String value) {
        return new JAXBElement<String>(_LoadAndImportDataInterfaceDetails_QNAME, String.class,
                                       LoadAndImportDataAsync.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     *
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace =
                    "http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/types/",
                    name = "notificationCode", scope = LoadAndImportDataAsync.class)
    public JAXBElement<String> createLoadAndImportDataAsyncNotificationCode(String value) {
        return new JAXBElement<String>(_LoadAndImportDataNotificationCode_QNAME, String.class,
                                       LoadAndImportDataAsync.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     *
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace =
                    "http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/types/",
                    name = "callbackURL", scope = LoadAndImportDataAsync.class)
    public JAXBElement<String> createLoadAndImportDataAsyncCallbackURL(String value) {
        return new JAXBElement<String>(_LoadAndImportDataCallbackURL_QNAME, String.class, LoadAndImportDataAsync.class,
                                       value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DocumentDetail }{@code >}
     *
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link DocumentDetail }{@code >}
     */
    @XmlElementDecl(namespace =
                    "http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/types/",
                    name = "document", scope = ImportBulkData.class)
    public JAXBElement<DocumentDetail> createImportBulkDataDocument(DocumentDetail value) {
        return new JAXBElement<DocumentDetail>(_ImportBulkDataDocument_QNAME, DocumentDetail.class,
                                               ImportBulkData.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     *
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace =
                    "http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/types/",
                    name = "notificationCode", scope = ImportBulkData.class)
    public JAXBElement<String> createImportBulkDataNotificationCode(String value) {
        return new JAXBElement<String>(_LoadAndImportDataNotificationCode_QNAME, String.class, ImportBulkData.class,
                                       value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     *
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace =
                    "http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/types/",
                    name = "callbackURL", scope = ImportBulkData.class)
    public JAXBElement<String> createImportBulkDataCallbackURL(String value) {
        return new JAXBElement<String>(_LoadAndImportDataCallbackURL_QNAME, String.class, ImportBulkData.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     *
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace =
                    "http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/types/",
                    name = "jobOptions", scope = ImportBulkData.class)
    public JAXBElement<String> createImportBulkDataJobOptions(String value) {
        return new JAXBElement<String>(_ImportBulkDataJobOptions_QNAME, String.class, ImportBulkData.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DocumentDetail }{@code >}
     *
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link DocumentDetail }{@code >}
     */
    @XmlElementDecl(namespace =
                    "http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/types/",
                    name = "document", scope = ImportBulkDataAsync.class)
    public JAXBElement<DocumentDetail> createImportBulkDataAsyncDocument(DocumentDetail value) {
        return new JAXBElement<DocumentDetail>(_ImportBulkDataDocument_QNAME, DocumentDetail.class,
                                               ImportBulkDataAsync.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     *
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace =
                    "http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/types/",
                    name = "notificationCode", scope = ImportBulkDataAsync.class)
    public JAXBElement<String> createImportBulkDataAsyncNotificationCode(String value) {
        return new JAXBElement<String>(_LoadAndImportDataNotificationCode_QNAME, String.class,
                                       ImportBulkDataAsync.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     *
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace =
                    "http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/types/",
                    name = "callbackURL", scope = ImportBulkDataAsync.class)
    public JAXBElement<String> createImportBulkDataAsyncCallbackURL(String value) {
        return new JAXBElement<String>(_LoadAndImportDataCallbackURL_QNAME, String.class, ImportBulkDataAsync.class,
                                       value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     *
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace =
                    "http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/types/",
                    name = "jobOptions", scope = ImportBulkDataAsync.class)
    public JAXBElement<String> createImportBulkDataAsyncJobOptions(String value) {
        return new JAXBElement<String>(_ImportBulkDataJobOptions_QNAME, String.class, ImportBulkDataAsync.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     *
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace =
                    "http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/types/",
                    name = "notificationCode", scope = ExtractAndPurge.class)
    public JAXBElement<String> createExtractAndPurgeNotificationCode(String value) {
        return new JAXBElement<String>(_LoadAndImportDataNotificationCode_QNAME, String.class, ExtractAndPurge.class,
                                       value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     *
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace =
                    "http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/types/",
                    name = "callbackURL", scope = ExtractAndPurge.class)
    public JAXBElement<String> createExtractAndPurgeCallbackURL(String value) {
        return new JAXBElement<String>(_LoadAndImportDataCallbackURL_QNAME, String.class, ExtractAndPurge.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     *
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace =
                    "http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/types/",
                    name = "jobOptions", scope = ExtractAndPurge.class)
    public JAXBElement<String> createExtractAndPurgeJobOptions(String value) {
        return new JAXBElement<String>(_ImportBulkDataJobOptions_QNAME, String.class, ExtractAndPurge.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     *
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace =
                    "http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/types/",
                    name = "notificationCode", scope = ExtractAndPurgeAsync.class)
    public JAXBElement<String> createExtractAndPurgeAsyncNotificationCode(String value) {
        return new JAXBElement<String>(_LoadAndImportDataNotificationCode_QNAME, String.class,
                                       ExtractAndPurgeAsync.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     *
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace =
                    "http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/types/",
                    name = "callbackURL", scope = ExtractAndPurgeAsync.class)
    public JAXBElement<String> createExtractAndPurgeAsyncCallbackURL(String value) {
        return new JAXBElement<String>(_LoadAndImportDataCallbackURL_QNAME, String.class, ExtractAndPurgeAsync.class,
                                       value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     *
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace =
                    "http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/types/",
                    name = "jobOptions", scope = ExtractAndPurgeAsync.class)
    public JAXBElement<String> createExtractAndPurgeAsyncJobOptions(String value) {
        return new JAXBElement<String>(_ImportBulkDataJobOptions_QNAME, String.class, ExtractAndPurgeAsync.class,
                                       value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     *
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace =
                    "http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/types/",
                    name = "parameterList", scope = ExportBulkData.class)
    public JAXBElement<String> createExportBulkDataParameterList(String value) {
        return new JAXBElement<String>(_ExportBulkDataParameterList_QNAME, String.class, ExportBulkData.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     *
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace =
                    "http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/types/",
                    name = "jobOptions", scope = ExportBulkData.class)
    public JAXBElement<String> createExportBulkDataJobOptions(String value) {
        return new JAXBElement<String>(_ImportBulkDataJobOptions_QNAME, String.class, ExportBulkData.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     *
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace =
                    "http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/types/",
                    name = "parameterList", scope = ExportBulkDataAsync.class)
    public JAXBElement<String> createExportBulkDataAsyncParameterList(String value) {
        return new JAXBElement<String>(_ExportBulkDataParameterList_QNAME, String.class, ExportBulkDataAsync.class,
                                       value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     *
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace =
                    "http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/types/",
                    name = "jobOptions", scope = ExportBulkDataAsync.class)
    public JAXBElement<String> createExportBulkDataAsyncJobOptions(String value) {
        return new JAXBElement<String>(_ImportBulkDataJobOptions_QNAME, String.class, ExportBulkDataAsync.class, value);
    }

}
