@javax.xml.bind.annotation.XmlSchema(namespace =
                                     "http://xmlns.oracle.com/apps/financials/commonModules/shared/model/erpIntegrationService/",
                                     elementFormDefault = javax.xml
                                                               .bind
                                                               .annotation
                                                               .XmlNsForm
                                                               .QUALIFIED)
package com.oracle.xmlns.apps.financials.commonmodules.shared.model.erpintegrationservice;

