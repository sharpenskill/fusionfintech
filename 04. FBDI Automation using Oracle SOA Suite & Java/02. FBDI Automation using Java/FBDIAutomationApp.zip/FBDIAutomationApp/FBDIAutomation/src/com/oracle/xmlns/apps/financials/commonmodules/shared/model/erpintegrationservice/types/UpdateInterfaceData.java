
package com.oracle.xmlns.apps.financials.commonmodules.shared.model.erpintegrationservice.types;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="processName" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="loadRequestId" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="document" type="{http://xmlns.oracle.com/adf/svc/types/}base64Binary-DataHandler"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = { "processName", "loadRequestId", "document" })
@XmlRootElement(name = "updateInterfaceData")
public class UpdateInterfaceData {

    @XmlElement(required = true)
    protected String processName;
    @XmlElement(required = true)
    protected String loadRequestId;
    @XmlElement(required = true)
    protected byte[] document;

    /**
     * Gets the value of the processName property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getProcessName() {
        return processName;
    }

    /**
     * Sets the value of the processName property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setProcessName(String value) {
        this.processName = value;
    }

    /**
     * Gets the value of the loadRequestId property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getLoadRequestId() {
        return loadRequestId;
    }

    /**
     * Sets the value of the loadRequestId property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setLoadRequestId(String value) {
        this.loadRequestId = value;
    }

    /**
     * Gets the value of the document property.
     *
     * @return
     *     possible object is
     *     byte[]
     */
    public byte[] getDocument() {
        return document;
    }

    /**
     * Sets the value of the document property.
     *
     * @param value
     *     allowed object is
     *     byte[]
     */
    public void setDocument(byte[] value) {
        this.document = value;
    }

}
