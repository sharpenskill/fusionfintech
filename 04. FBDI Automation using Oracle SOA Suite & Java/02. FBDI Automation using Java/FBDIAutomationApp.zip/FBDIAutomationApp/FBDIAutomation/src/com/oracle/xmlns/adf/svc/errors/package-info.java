@javax.xml.bind.annotation.XmlSchema(namespace = "http://xmlns.oracle.com/adf/svc/errors/",
                                     elementFormDefault =
                                     javax.xml
                                                                                                                      .bind
                                                                                                                      .annotation
                                                                                                                      .XmlNsForm
                                                                                                                      .QUALIFIED)
package com.oracle.xmlns.adf.svc.errors;

